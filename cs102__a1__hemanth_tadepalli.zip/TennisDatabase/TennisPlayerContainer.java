// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 1


package TennisDatabase;

// Custom (checked) exception for the TennisDatabase package, representing critical runtime errors (that must be handled).
public class TennisPlayerContainer implements TennisPlayerContainerInterface {
   private TennisPlayerContainerNode head;
   private int num; 
   
   public TennisPlayerContainer(){
      this.head = null;
      this.num = 0;
   }
   
     
   
   
   
 // Desc.: Search for a player in this container by input id, and returns a copy of that player (if found).
   // Output: Throws an unchecked (non-critical) exception if there is no player with that input id.
   public TennisPlayer getPlayer( String id ) throws TennisDatabaseRuntimeException{
      TennisPlayerContainerNode tempHead = this.head;
     
      for( int i = 0; i < this.num; i++){
         
        if(id.equals(tempHead.getPlayer().getId()) ){
         return tempHead.getPlayer();
        }
        tempHead=tempHead.getNext();
      } 
     
      return null;
   }
         

   // Desc.: Insert a tennis player into this container.
   // Input: A tennis player.
   // Output: Throws a checked (critical) exception if player id is already in this container.
   //         Throws a checked (critical) exception if the container is full.
   public void insertPlayer( TennisPlayer p ) throws TennisDatabaseException {
      TennisPlayerContainerNode newPlayer = new TennisPlayerContainerNode(p);
      if (this.num == 0){
      
         this.head = newPlayer;
         newPlayer.setNext(newPlayer);
      
         newPlayer.setPrev(newPlayer); 
      }
      else{
      
         TennisPlayerContainerNode temp = this.head;
         for( int i = 0; i < this.num; i++){
            if(temp.getPlayer().compareTo(newPlayer.getPlayer()) > 0){ 
             break;
              
            }
            temp = temp.getNext();
         } 
         temp.getPrev().setNext(newPlayer);
         newPlayer.setPrev(temp.getPrev());
         newPlayer.setNext(temp);
         temp.setPrev(newPlayer);        
      }
        this.num++;
      
    }
   
   // Desc.: Insert a tennis match into the lists of both tennis players of the input match.
   // Input: A tennis match.
   // Output: Throws a checked (critical) exception if the insertion is not fully successful.
   public void insertMatch( TennisMatch m ) throws TennisDatabaseException{
   
      TennisPlayerContainerNode temp = this.head;
      
      for( int i = 0; i < this.num; i++){
         if(temp.getPlayer().getId().equals(m.getIdPlayer1())||temp.getPlayer().getId().equals(m.getIdPlayer2())){
      
            temp.insertMatch(m);
      
         }
         temp = temp.getNext();
      }
  }

   
   
   // Desc.: Returns all players in the database arranged in the output array (sorted by id, alphabetically).
   // Output: Throws an unchecked (non-critical) exception if there are no players in this container.
   public TennisPlayer[] getAllPlayers() throws TennisDatabaseRuntimeException{
   TennisPlayerContainerNode tempHead = this.head;
   TennisPlayer[] players = new TennisPlayer[this.num];
      for(int i = 0; i<this.num; i++){
      
         players[i]= tempHead.getPlayer();
         tempHead = tempHead.getNext();
      }
      return players;
   }

   
   // Desc.: Returns copies (deep copies) of all matches of input player (id) arranged in the output array (sorted by date, most recent first).
   // Input: The id of a player.
   // Output: Throws a checked (critical) exception if the player (id) does not exists.
   //         Throws an unchecked (non-critical) exception if there are no matches (but the player id exists).
   public TennisMatch[] getMatchesOfPlayer( String playerId  ) throws TennisDatabaseException, TennisDatabaseRuntimeException{
   
       TennisPlayerContainerNode tempHead = this.head;
      for( int i = 0; i < this.num; i++){
        if(playerId.equals(tempHead.getPlayer().getId())){
         return tempHead.getMatches();
        }
        tempHead=tempHead.getNext();
      } 
      throw new TennisDatabaseException("Player ID not found!");
      

   
   }
}


  
   
   
   
   
   
   
   
   
   