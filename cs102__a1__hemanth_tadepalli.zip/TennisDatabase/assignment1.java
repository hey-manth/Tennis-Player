// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 1


package TennisDatabase;
import java.lang.String;
import java.util.*;
import java.io.*;
import java.util.Scanner;
 
public class assignment1 {
   public static void main(String[] args) throws Exception {
      Scanner user_sc = new Scanner(System.in);
      //System.out.println("Enter File Name: ");
      //String filename = user_sc.nextLine();
      String filename = "/Users/hemanthtadepalli/Desktop/Assignment 1 C/TennisDatabase/example_input_file.txt";
      System.out.println(filename);
      File file = new File(filename);
      Scanner file_sc = new Scanner(file); 
      while (file_sc.hasNextLine()){
         System.out.println(file_sc.nextLine());
      }
      
      TennisDatabase data = new TennisDatabase();
      data.loadFromFile( filename ); 
      
      String choice = " 0 ";
      while(!choice.equals("6")){
         
         System.out.println("\n\nCS-102 Tennis Manager - Available commands:");
         System.out.println("1 --> Print all tennis players");
         System.out.println("2 --> Print all tennis matches of a player");
         System.out.println("3 --> Print all tennis matches");
         System.out.println("4 --> Insert a new tennis player");
         System.out.println("5 --> Insert a new tennis match");
         System.out.println("6 --> Exit");
         System.out.print("Your choice? ");
         choice = user_sc.nextLine();
         
         System.out.println(choice);
         TennisMatch[] ms;
         switch(choice){
            case "1":
               
               TennisPlayer[] ps = data.getAllPlayers();
               for( int i = 0; i < ps.length; i++){
                   System.out.println(ps[i].getId() + ": " + ps[i].getFirstName() + " " + ps[i].getLastName() + " , " +  
                  
                  ps[i].getBirthYear() + " , " + ps[i].getCountry() +  " , " + data.getWinsOfPlayer(ps[i].getId()) + " / " + 
                  
                  (data.getMatchesOfPlayer( ps[i].getId()).length - data.getWinsOfPlayer(ps[i].getId())));
               }
            
               break;
               
            case "2":
               System.out.print("Enter Player Id: ");
               String id = user_sc.nextLine();
         
               System.out.println(id);
              ms = data.getMatchesOfPlayer( id );
              for( int i = 0; i < ms.length; i++){
                   System.out.println(ms[i].getDateYear() + "/ " + ms[i].getDateMonth() + " / " + ms[i].getDateDay() + " , " + 
                  
                  data.getPlayer(ms[i].getIdPlayer1()).getFirstName().substring(0,1) + " . " + data.getPlayer(ms[i].getIdPlayer1()).getLastName() + " - " +
                  data.getPlayer(ms[i].getIdPlayer2()).getFirstName().substring(0,1) + " . " + data.getPlayer(ms[i].getIdPlayer2()).getLastName() + ", " +
                  ms[i].getTournament()+ " , " + ms[i].getMatchScore());
                  
              }
            
   
   
            
            
               break;
               
            case "3":
            
                 ms = data.getAllMatches();
                for( int i = 0; i < ms.length; i++){
                   System.out.println(ms[i].getDateYear() + "/ " + ms[i].getDateMonth() + " / " + ms[i].getDateDay() + " , " + 
                  
                  data.getPlayer(ms[i].getIdPlayer1()).getFirstName().substring(0,1) + " . " + data.getPlayer(ms[i].getIdPlayer1()).getLastName() + " - " +
                  data.getPlayer(ms[i].getIdPlayer2()).getFirstName().substring(0,1) + " . " + data.getPlayer(ms[i].getIdPlayer2()).getLastName() + ", " +
                  ms[i].getTournament()+ " , " + ms[i].getMatchScore());
                  
              }
            
              
   
               break;
               
            case "4":
               System.out.print("Enter Player Id: ");
               String pid = user_sc.nextLine();
               System.out.print("Enter Player First Name: ");
               String firstName = user_sc.nextLine();
               System.out.print("Enter Player Last Name: ");
               String lastName = user_sc.nextLine();
               System.out.print("Enter Player Birth Year: ");
               String year = user_sc.nextLine();
               System.out.print("Enter Player Country: ");
               String country = user_sc.nextLine();
   
               
   
   
   
               data.insertPlayer( pid, firstName, lastName,Integer.parseInt(year), country );
            
               break;
               
            case "5":
               
               System.out.print("Enter Player Id1: ");
               String pid1 = user_sc.nextLine();
               System.out.print("Enter Player Id2: ");
               String pid2 = user_sc.nextLine();
               System.out.print("Enter Match Year: ");
               String mYear = user_sc.nextLine();
               System.out.print("Enter Match Month: ");
               String mMonth = user_sc.nextLine();
               System.out.print("Enter Match Day: ");
               String mDay = user_sc.nextLine();
               System.out.print("Enter Tournament: ");
               String tournament = user_sc.nextLine();
               System.out.print("Enter Scores: ");
               String scores = user_sc.nextLine();

   
            
               data.insertMatch( pid1, pid2, Integer.parseInt(mYear), Integer.parseInt(mMonth), Integer.parseInt(mDay),  tournament, scores );
            
               break;
               
            case "6":
               break;
               
            default: 
               System.out.println("Invalid Choice!\n");
               
               break;
               
         }
      }
            
         
            
         
         
             
   }
}



