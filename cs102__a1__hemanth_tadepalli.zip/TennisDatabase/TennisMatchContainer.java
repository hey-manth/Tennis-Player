// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 1



package TennisDatabase;
import java.util.*;
// Custom (checked) exception for the TennisDatabase package, representing critical runtime errors (that must be handled).
public class TennisMatchContainer extends ArrayList<TennisMatch> implements TennisMatchContainerInterface {

   
   
   
    // Desc.: Insert a tennis match into this container.
   // Input: A tennis match.
   // Output: Throws a checked (critical) exception if the container is full.
   public void insertMatch( TennisMatch m ) throws TennisDatabaseException{
      this.add (m);
      Collections.sort(this);
      Collections.reverse(this);
   }
   
   // Desc.: Returns all matches in the database arranged in the output array (sorted by date, most recent first).
   // Output: Throws an exception if there are no matches in this container.
   public TennisMatch[] getAllMatches() throws TennisDatabaseRuntimeException{
      TennisMatch[] matches = new TennisMatch[this.size()];
      for(int i = 0; i<this.size(); i++){
      
         matches[i]= this.get(i);
      }
      return matches;
   }
   
   // Desc.: Returns all matches of input player (id) arranged in the output array (sorted by date, most recent first).
   // Input: The id of the tennis player.
   // Output: Throws an unchecked (non-critical) exception if there are no tennis matches in the list.
   public TennisMatch[] getMatchesOfPlayer( String playerId ) throws TennisDatabaseRuntimeException{
      TennisMatch[] matches = new TennisMatch[this.size()];
      for(int i = 0; i<this.size(); i++){
         if (playerId.equals(this.get(i).getIdPlayer1()))
         {
            matches[i]= this.get(i);
         }
         if (playerId.equals(this.get(i).getIdPlayer2()))
         {
            matches[i]= this.get(i);
         }

      }
      return matches;
   }

}
