// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 1


package TennisDatabase;

// Custom (checked) exception for the TennisDatabase package, representing critical runtime errors (that must be handled).
public class TennisPlayerContainerNode implements TennisPlayerContainerNodeInterface {
   private SortedLinkedList<TennisMatch> matchList;
   private TennisPlayer player;
   private TennisPlayerContainerNode prev,next;
   
   
   public TennisPlayerContainerNode (TennisPlayer player) {
   
      this.player = player;
      this.prev = null;
      this.next = null;
      this.matchList = new SortedLinkedList<TennisMatch>();
   } 
    
    
    // Accessors (getters).
   public TennisPlayer getPlayer(){
    
      return this.player;
   }
   
   public TennisPlayerContainerNode getPrev(){
   
      return this.prev;
   }
   
   public TennisPlayerContainerNode getNext(){
      
      return this.next;
   }
   
  
   // Modifiers (setters).
   public void setPrev( TennisPlayerContainerNode p ){
   
      this.prev = p;
   }
   
   public void setNext( TennisPlayerContainerNode n ){
   
      this.next = n;
   }
   
   
   
   // Desc.: Insert a TennisMatch object (reference) into this node.
   // Input: A TennisMatch object (reference).
   // Output: Throws a checked (critical) exception if match cannot be inserted in this player list.
   public void insertMatch( TennisMatch m ) throws TennisDatabaseException{
   
       try{
      
       this.matchList.insert(m);
      }
      catch(Exception e){
      
         throw new TennisDatabaseException("Linked list insertion of a match failed!");
      }
   }
   
   
   // Desc.: Returns all matches of this player arranged in the output array (sorted by date, most recent first).
   // Output: Throws an unchecked (non-critical) exception if there are no matches for this player.
   public TennisMatch[] getMatches() throws TennisDatabaseRuntimeException{
   
      TennisMatch[] matches = new TennisMatch[this.matchList.size()];
      for(int i = 0; i<this.matchList.size(); i++){
      
         matches[i]= this.matchList.get(i);
      }
      return matches;
   }
  
      
      
   


      
}
