// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 1


package TennisDatabase;

// Custom (checked) exception for the TennisDatabase package, representing critical runtime errors (that must be handled).
public class TennisPlayer implements TennisPlayerInterface {



   private String playerId;
   private String firstName;
   private String lastName;
   private int birthYear;
   private String country;

   
   
  
   //Creating the constructors 
   public TennisPlayer()
   {
	      this.playerId = "[No ID]";
	      this.firstName = null;
	      this.lastName = null;
	      this.birthYear = 0;
	      this.country = null;
	      
   }
   //constructor with parameters
   public TennisPlayer(String playerId, String firstName, String lastName, int birthYear, String country)
   {
      this.playerId = playerId;
      this.firstName = firstName;
      this.lastName = lastName;
      this.birthYear = birthYear;
      this.country = country;
    
   }


   

   //constructor for another player
   public TennisPlayer(TennisPlayer other)
   {
         this.playerId = other.getId();
         this.firstName = other.getFirstName();
         this.lastName = other.getLastName();
         this.birthYear = other.getBirthYear();
         this.country = other.getCountry();
         //this.win = other.getWin();
         //this.loss = other.getLoss();
   }
   
   public String getId(){
      return this.playerId;  
   }
     
   public String getFirstName(){
     return this.firstName;
   }
   public String getLastName() {
     return this.lastName;
   }
   public int getBirthYear() {
     return this.birthYear;
   }
   public String getCountry() {
     return this.country;
   }
   public int compareTo (TennisPlayer other) {
      return this.playerId.compareTo(other.getId());
         
   }
}

   